<?php
session_start();
// mysqli database connection
const DB_NAME = 'pictogram';
const DB_HOST = 'localhost:3307';
const DB_USER = 'root';
const DB_PASS = '';